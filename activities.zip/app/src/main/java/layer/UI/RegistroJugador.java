package layer.UI;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import layer.Entities.*;

public class RegistroJugador extends AppCompatActivity {
    public ListaJugadores<Jugador> lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_jugador);
        instanciarObjetos();
    }

    public void instanciarObjetos(){
        lista = new ListaJugadores<Jugador>();
    }

    public void BtnRegistrar(View view){
        EditText txtNombreJugador = findViewById(R.id.etNombre);
        if (txtNombreJugador.getText().toString().isEmpty()){
            Toast.makeText(this, "Debe ingresar un nombre", Toast.LENGTH_SHORT).show();
        }
        else{
            Jugador nuevoJugador = new Jugador(txtNombreJugador.getText().toString());
            Toast.makeText(this, nuevoJugador.getNombre() + ", registrado", Toast.LENGTH_SHORT).show();
            txtNombreJugador.setText("");
            lista.addLast(nuevoJugador);
        }
    }
}